# 🐾 My Pet Token — Web3 Pet Game (เอกสารสรุปโครงการฉบับสมบูรณ์)

เอกสารนี้รวบรวมรายละเอียด สถาปัตยกรรมระบบ โครงสร้าง Smart Contracts ระบบการทำงานของ Frontend (HTML5 Canvas & Ethers.js) และขั้นตอนการทำงานของระบบ Web3 Play-to-Earn แบบ Single-Token Ecosystem 

---

## 📌 1. แนวคิดหลักและสถาปัตยกรรมระบบ (System Architecture)

**My Pet Token** คือเกมเลี้ยงสัตว์เสมือนจริงแบบ Web3 ที่มุ่งเน้นความโปร่งใสและ Decentralized อย่างแท้จริง โดยใช้ **PET Token (ERC-20)** เพียงเหรียญเดียวในทั้งระบบ ทั้งเป็นรางวัลจากการทำภารกิจและเป็นสกุลเงินในการซื้อไอเทม

### 1.1 การบริหารจัดการ Wallet

ระบบแบ่งโครงสร้าง Wallet ออกเป็น 2 ส่วนชัดเจน:

*   **Wallet A (Admin / Treasury Wallet):**
    *   กระเป๋าของผู้ดูแลระบบที่เป็นผู้ถือครอง PET Token ทั้งหมดในตอนเริ่มต้น (Initial Mint: 1,000,000 PET)
    *   ทำหน้าที่ฝาก (Deposit) PET Token สำรองเข้าสู่ `RewardContract` เพื่อเป็นกองทุนแจกรางวัล (Vault Pool)
    *   *ไม่ใช่กระเป๋าที่ใช้ในการเล่นเกม*
*   **Wallet B (Player / MetaMask Wallet):**
    *   กระเป๋า MetaMask ของผู้เล่นที่เชื่อมต่อเข้ากับเว็บไซต์
    *   รับโอนเหรียญ PET Token โดยตรงจาก `RewardContract` บนบล็อกเชนเมื่อทำภารกิจสำเร็จ (Auto-Reward)
    *   ถือกรรมสิทธิ์ PET Token บน Blockchain จริง (`balanceOf(Wallet B)`)
    *   ใช้ PET Token ของตนเองทำการ `approve()` และอนุมัติให้ `ShopContract` ดึงเหรียญไปชำระค่าไอเทม

### 1.2 System Architecture Diagram

```text
 ┌────────────────────────────────────────────────────────────────────────┐
 │                             CLIENT BROWSER                             │
 │                                                                        │
 │  ┌────────────────────────┐                ┌────────────────────────┐  │
 │  │   HTML5 Canvas View    │                │  UI Dashboard / Pages  │  │
 │  │ - Interactive Pet Render│                │ - Home / Wallet Info   │  │
 │  │ - Capybara / Accessories│                │ - Pet Stats / Actions  │  │
 │  │ - Floating Orange      │                │ - 15 Missions List     │  │
 │  └───────────┬────────────┘                │ - Item Shop            │  │
 │              │                             └───────────┬────────────┘  │
 │              └───────────────────┬─────────────────────┘               │
 │                                  │                                     │
 │                            Ethers.js v5.7                              │
 └──────────────────────────────────┼─────────────────────────────────────┘
                                    │
                            MetaMask Extension
                                    │ (Wallet B Provider/Signer)
 ┌──────────────────────────────────▼─────────────────────────────────────┐
 │                  BLOCKCHAIN TESTNET SMART CONTRACTS                    │
 │                                                                        │
 │   ┌─────────────────┐       ┌──────────────────┐                       │
 │   │   Wallet A      │       │  PETToken.sol    │                       │
 │   │ (Admin/Treasury)│──────>│ (ERC-20 Standard)│                       │
 │   └────────┬────────┘ Mint  └────────▲─────────┘                       │
 │            │                         │                                 │
 │     Deposit│Reserve                  │ Balance Check / Transfer        │
 │            ▼                         │                                 │
 │   ┌─────────────────┐                │                                 │
 │   │ RewardContract  │────────────────┤ (Auto-Reward 10 PET)            │
 │   │ (Mission Vault) │                │                                 │
 │   └─────────────────┘                │                                 │
 │            ▲                         │                                 │
 │   Claim Buy│                         │                                 │
 │   ┌────────┴────────┐                │                                 │
 │   │  ShopContract   │────────────────┘ (approve / transferFrom)        │
 │   │ (Items System)  │                                                  │
 │   └─────────────────┘                                                  │
 └────────────────────────────────────────────────────────────────────────┘
```

---

## 🪙 2. PET Token & Complete System Flow

### 2.1 คุณลักษณะของ PET Token
* **Token Name:** My Pet Token
* **Symbol:** PET
* **Standard:** ERC-20
* **Network:** Blockchain Testnet (เช่น Sepolia, Amoy, Hardhat Local)
* **Decimals:** 18

### 2.2 Complete System Flow (ขั้นตอนการทำงานทั้งระบบ)

```text
 [1. เปิดเว็บไซต์] 
         │
         ▼
 [2. Connect MetaMask] ───> อ่าน Wallet B Address & อ่าน PET Balance จริงจาก Blockchain
         │
         ▼
 [3. เลือกสัตว์เลี้ยง] ───> (คาปิบาร่า / แมว / สุนัข / กระต่าย)
         │
         ▼
 [4. ทำกิจกรรม Feed / Play / Clean] ───> อัปเดตสถานะ Hunger/Happiness & Mission Progress
         │
         ▼
 [5. ทำภารกิจสำเร็จ (Missions 1-15)] ───> กด "Claim Reward" บนหน้าเว็บ
         │
         ▼
 [6. Auto Reward Contract] ───> ตรวจสอบเงื่อนไข & โอน 10 PET จาก Vault เข้า Wallet B
         │
         ▼
 [7. ตรวจสอบ Blockchain Balance] ───> ยอด PET ใน MetaMask ของ Wallet B เพิ่มขึ้นจริง 
         │
         ▼
 [8. เข้าใช้งาน Shop] ───> เลือกซื้อไอเทม (อาหาร / เสื้อผ้า / ของตกแต่ง)
         │
         ▼
 [9. Approve & Buy Item] ───> ผู้เล่นกดยืนยันใน MetaMask (approve + transferFrom)
         │
         ▼
[10. Shop Contract รับ PET] ───> หัก PET จาก Wallet B และมอบไอเทมเข้า Inventory สัตว์เลี้ยง
```

---

## 📜 3. สถาปัตยกรรม Smart Contracts

โปรเจกต์นี้ประกอบด้วย 3 Smart Contracts หลัก เขียนด้วย Solidity `^0.8.20`

### 3.1 `PETToken.sol`
จัดการเหรียญมาตรฐาน ERC-20 สำหรับทั้งระบบ

```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract PETToken is ERC20, Ownable {
    constructor(uint256 initialSupply) ERC20("My Pet Token", "PET") Ownable(msg.sender) {
        _mint(msg.sender, initialSupply * 10**decimals());
    }

    function mint(address to, uint256 amount) public onlyOwner {
        _mint(to, amount);
    }
}
```

### 3.2 `RewardContract.sol`
จัดเก็บกองทุน PET ที่เติมโดย Wallet A และจ่ายรางวัล 10 PET อัตโนมัติเมื่อ Wallet B ทำภารกิจสำเร็จ โดยมีระบบป้องกันการเคลมภารกิจเดิมซ้ำ

```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract RewardContract is Ownable {
    IERC20 public petToken;
    uint256 public constant REWARD_AMOUNT = 10 * 10**18; // 10 PET per mission

    // Player Address => Mission ID => Claimed Status
    mapping(address => mapping(uint256 => bool)) public hasClaimedMission;

    event MissionRewarded(address indexed player, uint256 indexed missionId, uint256 rewardAmount);

    constructor(address _tokenAddress) Ownable(msg.sender) {
        petToken = IERC20(_tokenAddress);
    }

    function claimMissionReward(uint256 missionId) external {
        require(missionId >= 1 && missionId <= 15, "Invalid Mission ID");
        require(!hasClaimedMission[msg.sender][missionId], "Mission reward already claimed");
        require(petToken.balanceOf(address(this)) >= REWARD_AMOUNT, "Insufficient PET reserve in vault");

        hasClaimedMission[msg.sender][missionId] = true;
        require(petToken.transfer(msg.sender, REWARD_AMOUNT), "PET Transfer failed");

        emit MissionRewarded(msg.sender, missionId, REWARD_AMOUNT);
    }

    function getVaultBalance() external view returns (uint256) {
        return petToken.balanceOf(address(this));
    }
}
```

### 3.3 `ShopContract.sol`
จัดการรายการสินค้าและรับชำระด้วย PET Token ผ่านฟังก์ชัน `transferFrom()`

```solidity
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract ShopContract is Ownable {
    IERC20 public petToken;

    struct Item {
        uint256 id;
        string name;
        uint256 price; // In Wei (10^18)
        uint8 itemType; // 0: Food, 1: Outfit/Accessory, 2: Deco
        uint256 effectValue;
    }

    mapping(uint256 => Item) public items;
    mapping(address => mapping(uint256 => uint256)) public playerInventory; // player => itemId => count

    event ItemPurchased(address indexed player, uint256 indexed itemId, uint256 price);

    constructor(address _tokenAddress) Ownable(msg.sender) {
        petToken = IERC20(_tokenAddress);
        
        // Register catalog items
        items[1] = Item(1, "Premium Apple", 5 * 10**18, 0, 15);
        items[2] = Item(2, "Tasty Orange", 10 * 10**18, 0, 30);
        items[3] = Item(3, "Cool Hat", 20 * 10**18, 1, 0);
        items[4] = Item(4, "Sunglasses", 20 * 10**18, 1, 0);
        items[5] = Item(5, "Golden Capybara Crown", 50 * 10**18, 1, 0);
    }

    function buyItem(uint256 itemId) external {
        Item memory item = items[itemId];
        require(item.price > 0, "Item does not exist");
        require(petToken.balanceOf(msg.sender) >= item.price, "Insufficient PET balance");

        // Transfer tokens from Player (Wallet B) to Shop Contract
        require(petToken.transferFrom(msg.sender, address(this), item.price), "Token transfer failed");

        playerInventory[msg.sender][itemId] += 1;
        emit ItemPurchased(msg.sender, itemId, item.price);
    }
}
```

---

## 🎨 4. Canvas Animation Engine & Coordinates

ระบบแสดงผลตัวละครใช้ HTML5 Canvas API ขนาด `400x400` พิกเซล ทำการ Render แอนิเมชันแบบสตรีม 60 FPS พร้อมคำนวณตำแหน่งไอเทมและส่วนประกอบสรีระของสัตว์เลี้ยง (เน้น คาปิบาร่า):

```text
                  (200, 142) [Orange Leaf]
                      \ 🍃
                     (200, 150) [Floating Orange / Head Orange]
                       ( 🍊 )
                     +---------+
                     |   HAT   |  (160, 150) -> (240, 160)
                     +---------+
                          ||
                       ( 200, 190 )  [HEAD CENTER]
                     .-----------.
                   /   (185,185)   \
                  |    👁️     👁️    |  [EYES - (215,185)]
                  |   [GLASSES]    |  (170, 205) - (230, 205)
                   \  (200,205)   /   [NOSE]
                     '-----------'
                           ||
                      ( 200, 240 )   [BODY CENTER]
                   .---------------.
                  /                 \
                 |                   |
                 |     CAPYBARA      |
                  \                 /
                   '---------------'
                      ||       ||
                    Leg 1     Leg 2
```

### ตารางพิกัดตำแหน่งอุปกรณ์และชิ้นส่วน (Coordinate Matrix)

| ชิ้นส่วน / ไอเทม | รูปทรง / ลักษณะ | พิกัดศูนย์กลาง/จุดเริ่มต้น | ขนาด / รัศมี | รายละเอียดสไตล์ |
| :--- | :--- | :--- | :--- | :--- |
| **Body (ลำตัว)** | Ellipse (วงรี) | `(200, 240)` | `rx: 70, ry: 55` | สี `#C48A54` (น้ำตาลส้ม) |
| **Head (หัว)** | Ellipse (วงรี) | `(200, 190)` | `rx: 45, ry: 40` | สี `#C48A54` |
| **Ears (หู)** | Arc (วงกลม) | L: `(165, 165)` R: `(235, 165)` | `r: 10` | สี `#9E6738` |
| **Eyes (ตา)** | Arc (วงกลม) | L: `(185, 185)` R: `(215, 185)` | `r: 4` | มีระบบสุ่มกะพริบตา `blinkTimer` |
| **Nose (จมูก)** | Rounded Rect | `(193, 200)` | `w: 14, h: 10` | สี `#5A3D28` |
| **Orange (ส้มบนหัว)** | Circle & Leaf | `(200, 150)` | `r: 14` | สี `#FFA500` (ส้ม) + ใบไม้ `#228B22` |
| **Hat (หมวกแก๊ป)** | Polygon / Rect | Base: `(160, 155)`, Top: `(175, 125)` | `w: 80, h: 30` | สี `#333333` พร้อมแถบคาดส้ม |
| **Glasses (แว่น)** | Double Circle | L: `(182, 185)` R: `(218, 185)` | `r: 10` | กรอบสี `#111111` หนา 3px |

---

## 📋 5. ระบบ 15 Missions (Auto-Reward Matrix)

ทำสำเร็จภารกิจใด รับทันที **10 PET Token** โอนเข้า Wallet B โดยตรง

1. **Daily Check-in:** เข้าใช้งานเกมประจำวัน
2. **First Meal:** ให้อาหารสัตว์เลี้ยง 1 ครั้ง
3. **Feed Master:** ให้อาหารสัตว์เลี้ยงสะสม 3 ครั้ง
4. **Feast Time:** ให้อาหารสัตว์เลี้ยงสะสม 5 ครั้ง
5. **Play Time:** เล่นกับสัตว์เลี้ยง 1 ครั้ง
6. **Joyful Companion:** เล่นกับสัตว์เลี้ยงสะสม 3 ครั้ง
7. **Best Friend:** เล่นกับสัตว์เลี้ยงสะสม 5 ครั้ง
8. **Happy Pet:** ทำค่า Happiness ให้ถึง 80
9. **Super Happy:** ทำค่า Happiness ให้ถึง 100
10. **Full Belly:** ทำค่า Hunger ให้ถึง 100
11. **Shopping Spree:** ซื้อไอเทมใน Shop 1 ครั้ง
12. **Fashionista:** ซื้อชุดแต่งตัว/แว่นตา 1 ชิ้น
13. **Clean & Tidy:** ดูแลทำความสะอาดสัตว์เลี้ยง 2 ครั้ง
14. **Pet Care Veteran:** ทำกิจกรรมรวม (Feed/Play) ครบ 10 ครั้ง
15. **Ultimate Master:** ปลดล็อกความสำเร็จสัตว์เลี้ยง Level 2

---

## 🛠️ 6. คู่มือการทดสอบและการใช้งาน (Getting Started)

1. **Deploy Smart Contracts:** 
   * ใช้ Remix IDE นำโค้ด `PETToken.sol`, `RewardContract.sol`, และ `ShopContract.sol` ไป Deploy บน Testnet
2. **Setup Reserve:** 
   * นำ Wallet A (Admin) โอนเหรียญ PET เข้าไปที่ที่อยู่ของ `RewardContract` (เช่น 1,000 PET)
3. **Configure Frontend:** 
   * นำ Address ของ Smart Contracts ทั้ง 3 สัญญาไปอัปเดตใส่ในส่วนกำหนดค่า JavaScript ในหน้าเว็บ
4. **Play Game:** 
   * เปิดหน้าเว็บ กด Connect MetaMask สลับเครือข่ายเป็น Testnet 
   * ทำภารกิจในเกมและกด Claim รับ 10 PET เข้ากระเป๋า MetaMask จริง!